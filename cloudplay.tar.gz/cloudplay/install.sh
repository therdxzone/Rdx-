#!/usr/bin/env bash
# CloudPlay installer for Ubuntu 22.04 / 24.04.
#   sudo bash install.sh                       # HTTP on port 80 (put a TLS proxy/CDN in front, or use DOMAIN below)
#   sudo DOMAIN=play.example.com EMAIL=you@example.com bash install.sh   # also obtains a Let's Encrypt certificate
#   sudo SKIP_IMAGE=1 bash install.sh          # skip building the Android emulator image (build later, see README)
set -euo pipefail

APP_USER=cloudplay
APP_DIR="${APP_DIR:-/opt/cloudplay}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOMAIN="${DOMAIN:-}"
EMAIL="${EMAIL:-}"
PORT="${PORT:-3000}"
CRED_FILE=/root/cloudplay-credentials.txt

c_ok()   { printf '\033[32m[ok]\033[0m %s\n' "$*"; }
c_warn() { printf '\033[33m[warn]\033[0m %s\n' "$*"; }
c_err()  { printf '\033[31m[error]\033[0m %s\n' "$*" >&2; }
die()    { c_err "$*"; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root: sudo bash install.sh"

# ---- 1. preflight ---------------------------------------------------------------------------------
. /etc/os-release
[[ "${ID:-}" == "ubuntu" ]] || die "This installer supports Ubuntu only (found: ${ID:-unknown})."
case "${VERSION_ID:-}" in 22.04|24.04) c_ok "Ubuntu ${VERSION_ID}";; *) die "Ubuntu 22.04 or 24.04 required (found ${VERSION_ID:-?}).";; esac

[[ "$(uname -m)" == "x86_64" ]] || die "x86_64 CPU required (found $(uname -m)); the emulator images are x86_64."

if grep -qE '(vmx|svm)' /proc/cpuinfo; then c_ok "CPU virtualization flags present"; else
  die "No hardware virtualization (vmx/svm). Android emulators need KVM. Use a bare-metal or nested-virtualization-enabled VPS."; fi
if [[ ! -e /dev/kvm ]]; then
  modprobe kvm 2>/dev/null || true; modprobe kvm_intel 2>/dev/null || modprobe kvm_amd 2>/dev/null || true
fi
if [[ -e /dev/kvm ]]; then c_ok "/dev/kvm available"; else
  die "/dev/kvm is missing. Ask your provider to enable nested virtualization / use a KVM-capable plan."; fi

MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
DISK_GB=$(df -BG --output=avail / | tail -1 | tr -dc '0-9')
(( MEM_MB >= 3500 )) || die "At least 4 GB RAM required (found ${MEM_MB} MB). Each emulator needs ~2 GB more."
(( MEM_MB >= 7500 )) || c_warn "Only ${MEM_MB} MB RAM: you will be able to run about $(( (MEM_MB-1500)/2200 )) emulator(s) at once."
(( DISK_GB >= 25 )) || die "At least 25 GB free disk required (found ${DISK_GB} GB)."
c_ok "RAM ${MEM_MB} MB, free disk ${DISK_GB} GB"

# ---- 2. dependencies ------------------------------------------------------------------------------
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y --no-install-recommends ca-certificates curl gnupg build-essential python3 make g++ ffmpeg nginx docker.io openssl ufw rsync cpu-checker
systemctl enable --now docker
c_ok "System packages installed"

if ! command -v node >/dev/null || [[ "$(node -v | cut -d. -f1 | tr -d v)" -lt 20 ]]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
c_ok "Node.js $(node -v)"
npm install -g pm2 >/dev/null 2>&1
c_ok "PM2 $(pm2 -v)"

# ---- 3. app user + files --------------------------------------------------------------------------
id -u "$APP_USER" >/dev/null 2>&1 || useradd --system --create-home --shell /usr/sbin/nologin "$APP_USER"
usermod -aG docker "$APP_USER"
usermod -aG kvm "$APP_USER" 2>/dev/null || true
mkdir -p "$APP_DIR"
rsync -a --delete --exclude node_modules --exclude storage --exclude logs --exclude .env "$SRC_DIR/" "$APP_DIR/"
mkdir -p "$APP_DIR/storage" "$APP_DIR/logs"
chown -R "$APP_USER:$APP_USER" "$APP_DIR"
chmod 750 "$APP_DIR/storage"

# ---- 4. configuration -----------------------------------------------------------------------------
if [[ ! -f "$APP_DIR/.env" ]]; then
  cp "$APP_DIR/.env.example" "$APP_DIR/.env"
  sed -i "s|^APP_SECRET=.*|APP_SECRET=$(openssl rand -hex 32)|; s|^PORT=.*|PORT=${PORT}|" "$APP_DIR/.env"
  if [[ -n "$DOMAIN" ]]; then
    sed -i "s|^PUBLIC_ORIGIN=.*|PUBLIC_ORIGIN=https://${DOMAIN}|; s|^COOKIE_SECURE=.*|COOKIE_SECURE=true|" "$APP_DIR/.env"
  else
    sed -i "s|^COOKIE_SECURE=.*|COOKIE_SECURE=false|" "$APP_DIR/.env"
    c_warn "No DOMAIN given: cookies are not marked Secure. Serve this over HTTPS (set DOMAIN, or put a TLS proxy in front and set COOKIE_SECURE=true)."
  fi
  chown "$APP_USER:$APP_USER" "$APP_DIR/.env"; chmod 600 "$APP_DIR/.env"
fi

# ---- 5. node modules + database -------------------------------------------------------------------
sudo -u "$APP_USER" bash -c "cd '$APP_DIR' && npm install --omit=dev --no-audit --no-fund"
c_ok "Node dependencies installed"
INIT_OUT=$(sudo -u "$APP_USER" bash -c "cd '$APP_DIR' && node backend/database/init.js")
ADMIN_PW=$(echo "$INIT_OUT" | sed -n 's/^INITIAL_ADMIN_PASSWORD=//p')
USER_PW=$(echo "$INIT_OUT" | sed -n 's/^INITIAL_USER_PASSWORD=//p')
if [[ -n "$ADMIN_PW" ]]; then
  umask 077
  { echo "CloudPlay initial credentials ($(date -u +%FT%TZ))"; echo "Admin password: $ADMIN_PW"; echo "Shared user password: $USER_PW"; echo "Change both in Admin > User Settings, then delete this file."; } > "$CRED_FILE"
  c_ok "Database created; credentials saved to $CRED_FILE (root only)"
else
  c_ok "Database already initialised; existing passwords kept"
fi

# ---- 6. emulator image ----------------------------------------------------------------------------
if [[ "${SKIP_IMAGE:-0}" != "1" ]]; then
  if ! docker image inspect cloudplay/android-emulator:latest >/dev/null 2>&1; then
    c_ok "Building Android emulator image (downloads ~2 GB, takes several minutes)..."
    docker build -t cloudplay/android-emulator:latest "$APP_DIR/emulator/image" || c_warn "Image build failed. Build it later: docker build -t cloudplay/android-emulator:latest $APP_DIR/emulator/image"
  fi
else
  c_warn "Skipping emulator image build (SKIP_IMAGE=1)."
fi

# ---- 7. nginx -------------------------------------------------------------------------------------
cat > /etc/nginx/sites-available/cloudplay <<EOF
map \$http_upgrade \$connection_upgrade { default upgrade; '' close; }
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN:-_};
    client_max_body_size 4g;          # APK uploads; the real limit is configurable in Admin > User Settings
    proxy_request_buffering off;
    location / {
        proxy_pass http://127.0.0.1:${PORT};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$connection_upgrade;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }
}
EOF
ln -sf /etc/nginx/sites-available/cloudplay /etc/nginx/sites-enabled/cloudplay
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
c_ok "Nginx configured"

if [[ -n "$DOMAIN" && -n "$EMAIL" ]]; then
  apt-get install -y certbot python3-certbot-nginx
  certbot --nginx -d "$DOMAIN" -m "$EMAIL" --agree-tos --non-interactive --redirect && c_ok "HTTPS certificate installed" || c_warn "certbot failed; check DNS for $DOMAIN and re-run: certbot --nginx -d $DOMAIN"
fi

# ---- 8. firewall (never expose adb/emulator ports) -------------------------------------------------
ufw allow OpenSSH >/dev/null 2>&1 || true
ufw allow 80/tcp >/dev/null 2>&1 || true
ufw allow 443/tcp >/dev/null 2>&1 || true
ufw --force enable >/dev/null 2>&1 || true
c_ok "Firewall: only SSH, 80 and 443 are open (adb/emulator ports stay inside containers)"

# ---- 9. PM2 + boot service ------------------------------------------------------------------------
cat > "$APP_DIR/ecosystem.config.js" <<EOF
module.exports = { apps: [{ name: 'cloudplay', script: 'backend/server.js', cwd: '${APP_DIR}', max_memory_restart: '512M', kill_timeout: 60000, env: { NODE_ENV: 'production' }, out_file: '${APP_DIR}/logs/out.log', error_file: '${APP_DIR}/logs/err.log', time: true }] };
EOF
chown "$APP_USER:$APP_USER" "$APP_DIR/ecosystem.config.js"
APP_HOME=$(getent passwd "$APP_USER" | cut -d: -f6)
sudo -u "$APP_USER" env PM2_HOME="$APP_HOME/.pm2" pm2 delete cloudplay >/dev/null 2>&1 || true
sudo -u "$APP_USER" env PM2_HOME="$APP_HOME/.pm2" pm2 start "$APP_DIR/ecosystem.config.js"
sudo -u "$APP_USER" env PM2_HOME="$APP_HOME/.pm2" pm2 save
env PATH="$PATH:/usr/bin" pm2 startup systemd -u "$APP_USER" --hp "$APP_HOME" >/dev/null 2>&1 || c_warn "pm2 startup registration failed; run: pm2 startup systemd -u $APP_USER --hp $APP_HOME"
systemctl enable "pm2-$APP_USER" >/dev/null 2>&1 || true
sleep 3
if curl -fsS "http://127.0.0.1:${PORT}/api/auth/info" >/dev/null; then c_ok "CloudPlay is responding"; else c_warn "App did not respond yet; see: sudo -u $APP_USER PM2_HOME=$APP_HOME/.pm2 pm2 logs cloudplay"; fi

# ---- 10. summary ----------------------------------------------------------------------------------
IP=$(curl -fsS -m 5 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')
echo
echo "=============================================================="
echo " CloudPlay installed"
echo "=============================================================="
echo " URL:            ${DOMAIN:+https://$DOMAIN}${DOMAIN:-http://$IP}"
echo " App directory:  $APP_DIR   (config: $APP_DIR/.env)"
[[ -f "$CRED_FILE" ]] && echo " Credentials:    sudo cat $CRED_FILE   (change them after first login)"
echo " Logs:           sudo -u $APP_USER PM2_HOME=$APP_HOME/.pm2 pm2 logs cloudplay"
echo " Health check:   sudo -u $APP_USER bash -c 'cd $APP_DIR && node scripts/check.js'"
echo " Troubleshooting: see README.md section 'Troubleshooting'"
echo "=============================================================="
