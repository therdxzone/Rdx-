'use strict';
const path = require('path');
const fs = require('fs');
const root = path.resolve(__dirname, '..', '..');
require('dotenv').config({ path: path.join(root, '.env') });

const abs = (p, d) => path.resolve(root, p || d);
const bool = (v, d) => (v === undefined || v === '' ? d : /^(1|true|yes)$/i.test(v));

const dataDir = abs(process.env.DATA_DIR, './storage');
const cfg = {
  root,
  env: process.env.NODE_ENV || 'development',
  host: process.env.HOST || '127.0.0.1',
  port: parseInt(process.env.PORT || '3000', 10),
  cookieSecure: bool(process.env.COOKIE_SECURE, false),
  publicOrigin: (process.env.PUBLIC_ORIGIN || '').replace(/\/$/, ''),
  appSecret: process.env.APP_SECRET || 'dev-secret',
  dataDir,
  dbFile: abs(process.env.DB_FILE, './storage/cloudplay.sqlite'),
  apkDir: path.join(dataDir, 'apks'),
  iconDir: path.join(dataDir, 'icons'),
  tmpDir: path.join(dataDir, 'tmp'),
  logDir: abs('./logs'),
  frontendDir: path.join(root, 'frontend'),
  emulator: {
    image: process.env.EMULATOR_IMAGE || 'cloudplay/android-emulator:latest',
    abis: (process.env.EMULATOR_ABIS || 'x86_64,x86').split(',').map((s) => s.trim()).filter(Boolean),
    armTranslation: bool(process.env.EMULATOR_ARM_TRANSLATION, false),
    network: process.env.EMULATOR_NETWORK || 'cloudplay-emu',
    bootTimeoutSec: parseInt(process.env.EMULATOR_BOOT_TIMEOUT_SEC || '300', 10),
    useKvm: bool(process.env.EMULATOR_USE_KVM, true),
  },
  stream: {
    fps: parseInt(process.env.STREAM_FPS || '30', 10),
    bitrate: parseInt(process.env.STREAM_BITRATE || '4000000', 10),
    stun: (process.env.STUN_URLS || 'stun:stun.l.google.com:19302').split(',').map((s) => s.trim()).filter(Boolean),
    turnUrl: process.env.TURN_URL || '',
    turnSecret: process.env.TURN_SECRET || '',
  },
};

for (const d of [cfg.dataDir, cfg.apkDir, cfg.iconDir, cfg.tmpDir, cfg.logDir]) {
  fs.mkdirSync(d, { recursive: true, mode: 0o750 });
}
module.exports = cfg;
