'use strict';
// Live capture: adb screenrecord (H.264) -> ffmpeg (decode, scale to I420) -> wrtc RTCVideoSource -> WebRTC.
// screenrecord stops after 3 minutes by design, so it is restarted seamlessly in a loop.
const { spawn } = require('child_process');
const { RTCVideoSource } = require('@roamhq/wrtc').nonstandard;
const { spawnAdb } = require('../emulator/docker');
const cfg = require('../config');

class CapturePipeline {
  constructor(container, width, height) {
    this.container = container; this.w = width; this.h = height;
    this.source = new RTCVideoSource();
    this.track = this.source.createTrack();
    this.closed = false; this.rec = null; this.ff = null; this.frames = 0; this.lastFrameAt = 0;
    this.start();
  }

  start() {
    if (this.closed) return;
    const { w, h } = this;
    const frameSize = w * h * 1.5;
    this.rec = spawnAdb(this.container, ['exec-out', 'screenrecord', '--output-format=h264', `--size=${w}x${h}`, `--bit-rate=${cfg.stream.bitrate}`, '-']);
    this.ff = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-fflags', 'nobuffer', '-flags', 'low_delay', '-probesize', '32', '-analyzeduration', '0',
      '-f', 'h264', '-i', 'pipe:0', '-vf', `fps=${cfg.stream.fps}`, '-pix_fmt', 'yuv420p', '-f', 'rawvideo', 'pipe:1'], { stdio: ['pipe', 'pipe', 'pipe'] });
    this.rec.stdout.pipe(this.ff.stdin);
    this.rec.stdin.on('error', () => {}); this.ff.stdin.on('error', () => {});
    this.rec.stderr.on('data', () => {}); this.ff.stderr.on('data', (d) => { this.lastError = d.toString().slice(0, 200); });

    let buf = Buffer.alloc(0);
    this.ff.stdout.on('data', (chunk) => {
      buf = buf.length ? Buffer.concat([buf, chunk]) : chunk;
      while (buf.length >= frameSize) {
        const frame = buf.subarray(0, frameSize);
        buf = buf.subarray(frameSize);
        // onFrame needs a standalone buffer; only the newest frame matters for low latency
        if (buf.length < frameSize) {
          this.source.onFrame({ width: w, height: h, data: new Uint8ClampedArray(frame) });
          this.frames++; this.lastFrameAt = Date.now();
        }
      }
    });
    const restart = () => { if (!this.closed) { this.killProcs(); setTimeout(() => this.start(), 300); } };
    this.rec.once('exit', restart);
    this.ff.once('exit', () => { if (!this.closed) restart(); });
  }

  killProcs() {
    for (const p of [this.rec, this.ff]) { try { p && p.removeAllListeners('exit'); p && p.kill('SIGKILL'); } catch { /* ignore */ } }
  }

  close() {
    this.closed = true;
    this.killProcs();
    try { this.track.stop(); } catch { /* ignore */ }
  }
}

module.exports = { CapturePipeline };
