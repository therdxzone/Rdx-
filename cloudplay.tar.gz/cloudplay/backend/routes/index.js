'use strict';
const express = require('express');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { loginLimiter, uploadLimiter } = require('../middleware/rateLimit');
const auth = require('../controllers/auth');
const games = require('../controllers/games');
const admin = require('../controllers/admin');
const play = require('../controllers/play');

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const r = express.Router();

// auth
r.get('/auth/info', auth.publicInfo);
r.post('/auth/login', loginLimiter, wrap(auth.login));
r.post('/auth/logout', auth.logout);
r.get('/auth/me', auth.me);

// user
r.get('/games', requireAuth, games.listForUsers);
r.get('/games/:id/icon', requireAuth, games.icon);
r.post('/play', requireAuth, wrap(play.start));
r.get('/play/:id', requireAuth, play.status);
r.delete('/play/:id', requireAuth, wrap(play.stop));
r.get('/play/:id/ice', requireAuth, play.ice);

// admin
const a = express.Router();
a.use(requireAdmin);
a.get('/overview', wrap(admin.overview));
a.get('/system', wrap(admin.sysStats));
a.get('/settings', admin.getSettings);
a.put('/settings', admin.putSettings);
a.put('/password', wrap(admin.changePassword));
a.get('/sessions', admin.listSessions);
a.delete('/sessions/login/:id', admin.terminateLogin);
a.delete('/sessions/play/:id', wrap(admin.terminatePlay));
a.get('/logs', admin.auditLogs);
a.get('/games', games.listForAdmin);
a.post('/games', uploadLimiter, games.handleUpload, wrap(games.create));
a.put('/games/:id', games.handleUpload, wrap(games.update));
a.delete('/games/:id', wrap(games.remove));
a.post('/games/:id/start', wrap(admin.gameStart));
a.post('/games/:id/stop', wrap(admin.gameStop));
a.post('/games/:id/restart', wrap(admin.gameRestart));
a.get('/games/:id/logs', games.logs);
a.get('/games/:id/install', wrap(admin.installStatus));
a.post('/games/:id/install/:op', wrap(admin.installOp));
r.use('/admin', a);

module.exports = r;
