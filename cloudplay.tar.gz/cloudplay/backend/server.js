'use strict';
const http = require('http');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const cfg = require('./config');
const { db, settings } = require('./database/db');
const { attachAuth, csrfProtect } = require('./middleware/auth');
const { apiLimiter } = require('./middleware/rateLimit');
const routes = require('./routes');
const manager = require('./emulator/manager');
const signaling = require('./streaming/signaling');

if (!settings.get('admin_hash') || !settings.get('user_hash')) {
  console.error('Database has no passwords yet. Run: npm run init-db');
  process.exit(1);
}

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 'loopback'); // Nginx on the same host
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: false,
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", 'https://cdn.tailwindcss.com'],
      styleSrc: ["'self'", "'unsafe-inline'"], // Tailwind CDN injects <style>
      imgSrc: ["'self'", 'data:', 'blob:'],
      connectSrc: ["'self'", 'ws:', 'wss:'],
      mediaSrc: ["'self'", 'blob:'],
      frameAncestors: ["'none'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
    },
  },
  crossOriginEmbedderPolicy: false,
}));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
app.use('/api', apiLimiter);
app.use(attachAuth);
app.use(csrfProtect);
app.use('/api', routes);
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found.' }));

// Static frontend only. Uploaded APKs/icons live in storage/ and are never served statically.
app.use(express.static(cfg.frontendDir, { index: 'index.html', maxAge: '5m', extensions: ['html'] }));

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: cfg.env === 'production' ? 'Internal server error.' : err.message });
});

const server = http.createServer(app);
signaling.attach(server);

(async () => {
  await manager.cleanupOrphans();
  manager.startMonitor();
  server.listen(cfg.port, cfg.host, () => console.log(`CloudPlay listening on http://${cfg.host}:${cfg.port}`));
})();

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, async () => {
    const rows = db.prepare("SELECT id FROM play_sessions WHERE status IN ('starting','booting','installing','launching','running')").all();
    await Promise.all(rows.map((r) => manager.stopSession(r.id, 'Server shutting down')));
    process.exit(0);
  });
}
