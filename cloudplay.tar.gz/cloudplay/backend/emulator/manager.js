'use strict';
const EventEmitter = require('events');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { db, settings } = require('../database/db');
const cfg = require('../config');
const system = require('../services/system');
const apk = require('../services/apk');
const authSessions = require('../services/authSessions');
const installs = require('./installs');
const { docker, adb, adbShell } = require('./docker');

const events = new EventEmitter();
const ACTIVE = ['starting', 'booting', 'installing', 'launching', 'running'];
const ACTIVE_SQL = "('starting','booting','installing','launching','running')";
const MAX_AUTO_RESTARTS = 2;
const OPS = ['reinstall', 'update', 'uninstall', 'clear-data', 'verify'];
const booting = new Set();

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const containerName = (id) => 'cp-' + id.replace(/-/g, '').slice(0, 16);

function log(gameId, playId, level, message) {
  db.prepare('INSERT INTO game_logs(game_id,play_id,level,message,ts) VALUES(?,?,?,?,?)').run(gameId, playId, level, String(message).slice(0, 2000), Date.now());
}
function setStatus(id, status, extra = {}) {
  const sets = ['status=?']; const vals = [status];
  for (const [k, v] of Object.entries(extra)) { sets.push(`${k}=?`); vals.push(v); }
  db.prepare(`UPDATE play_sessions SET ${sets.join(',')} WHERE id=?`).run(...vals, id);
}
const getSession = (id) => db.prepare('SELECT * FROM play_sessions WHERE id=?').get(id);

async function runtimeStatus() {
  const out = { docker: false, imagePresent: false, kvm: fs.existsSync('/dev/kvm'), image: cfg.emulator.image, network: cfg.emulator.network, abis: cfg.emulator.abis };
  try { await docker(['version', '--format', '{{.Server.Version}}'], { timeout: 5000 }); out.docker = true; } catch (e) { out.error = 'Docker unavailable: ' + e.message; return out; }
  try { await docker(['image', 'inspect', cfg.emulator.image], { timeout: 8000 }); out.imagePresent = true; } catch { out.error = `Emulator image "${cfg.emulator.image}" not found. Build it: docker build -t ${cfg.emulator.image} emulator/image`; }
  return out;
}

async function ensureNetwork() {
  const n = cfg.emulator.network;
  if (!n || n === 'none' || n === 'bridge' || n === 'host') return n || 'none';
  try { await docker(['network', 'inspect', n], { timeout: 8000 }); } catch {
    await docker(['network', 'create', '--driver', 'bridge', '-o', 'com.docker.network.bridge.enable_icc=false', n], { timeout: 15000 });
  }
  return n;
}

// Stop the emulator cleanly so Android flushes its data to the persistent volume, then remove ONLY the
// container. The volume (installed games + game data) is never touched here.
async function shutdownContainer(name) {
  await adb(name, ['emu', 'kill'], { timeout: 8000 }).catch(() => {});
  await docker(['stop', '-t', '20', name], { timeout: 45000 }).catch(() => {});
  await docker(['rm', '-f', name], { timeout: 30000 }).catch(() => {});
}

// ---- resource gate ----------------------------------------------------------------------------
function checkResources(game) {
  const maxEmu = settings.int('max_emulators');
  const active = db.prepare(`SELECT COUNT(*) c FROM play_sessions WHERE status IN ${ACTIVE_SQL}`).get().c;
  if (active >= maxEmu) throw new HttpError(503, `All ${maxEmu} emulator slot(s) are in use. Please try again in a few minutes.`);
  const ramCap = settings.int('ram_per_emulator_mb'); const cpuCap = settings.int('cpu_per_emulator');
  if (game.min_ram_mb > ramCap) throw new HttpError(503, `This game needs ${game.min_ram_mb} MB RAM but the per-emulator limit is ${ramCap} MB.`);
  if (game.cpu_cores > cpuCap) throw new HttpError(503, `This game needs ${game.cpu_cores} CPU cores but the per-emulator limit is ${cpuCap}.`);
  const mem = system.memInfo();
  const needBytes = (game.min_ram_mb + 512) * 1024 * 1024;
  if (mem.availableBytes < needBytes) throw new HttpError(503, `Not enough free RAM on the server (${Math.round(mem.availableBytes / 1048576)} MB available, ${Math.round(needBytes / 1048576)} MB needed).`);
  const allocated = db.prepare(`SELECT COALESCE(SUM(g.cpu_cores),0) c FROM play_sessions p JOIN games g ON g.id=p.game_id WHERE p.status IN ${ACTIVE_SQL}`).get().c;
  if (allocated + game.cpu_cores > system.cores()) throw new HttpError(503, `Not enough free CPU cores (${system.cores() - allocated} free, ${game.cpu_cores} needed).`);
}

// ---- public API -------------------------------------------------------------------------------
// op = null for normal play, or one of OPS for an admin maintenance run on the game's persistent instance.
async function startSession({ authId, role, gameId, adminTest = false, op = null }) {
  if (op && !OPS.includes(op)) throw new HttpError(400, 'Unknown operation.');
  const game = db.prepare('SELECT * FROM games WHERE id=?').get(gameId);
  if (!game) throw new HttpError(404, 'Game not found.');
  if (!game.enabled && !(adminTest && role === 'admin')) throw new HttpError(403, 'This game is currently disabled.');

  if (op !== 'uninstall' && op !== 'clear-data' && op !== 'verify') {
    const compat = apk.isCompatible(game.abis ? game.abis.split(',') : [], cfg.emulator.abis, cfg.emulator.armTranslation);
    if (!compat.ok) throw new HttpError(422, compat.reason);
  }

  // one live session per login: reuse if identical, otherwise replace
  const mine = db.prepare(`SELECT * FROM play_sessions WHERE auth_session_id=? AND status IN ${ACTIVE_SQL}`).all(authId);
  for (const s of mine) {
    if (s.game_id === gameId && (s.op || null) === (op || null)) return { id: s.id, status: s.status, reused: true };
    await stopSession(s.id, 'Replaced by a new request');
  }

  // The game's persistent instance can only be mounted by one emulator at a time.
  const busy = db.prepare(`SELECT id,op FROM play_sessions WHERE game_id=? AND status IN ${ACTIVE_SQL} LIMIT 1`).get(gameId);
  if (busy) throw new HttpError(409, busy.op ? `This game is under maintenance (${busy.op}). Try again in a few minutes.` : 'This game is currently being played by someone else. Its emulator can host one player at a time; try again shortly.');

  const rt = await runtimeStatus();
  if (!rt.docker || !rt.imagePresent) throw new HttpError(503, rt.error || 'Emulator runtime is not ready.');
  if (cfg.emulator.useKvm && !rt.kvm) throw new HttpError(503, 'This server has no /dev/kvm; hardware acceleration is required to run emulators.');

  checkResources(game);

  const id = crypto.randomUUID();
  const now = Date.now();
  db.prepare(`INSERT INTO play_sessions(id,auth_session_id,role,game_id,container,status,started_at,expires_at,op) VALUES(?,?,?,?,?,?,?,?,?)`)
    .run(id, authId, role, gameId, containerName(id), 'starting', now, now + (op ? 60 : settings.int('play_duration_min')) * 60000, op);
  const inst = installs.ensure(game);
  if (op) installs.set(game.id, { busy_op: op });
  log(gameId, id, 'info', op ? `Maintenance "${op}" requested by ${role}` : `Session ${id} requested by ${role}`);
  boot(id).catch((e) => failSession(id, e));
  return { id, status: 'starting', op };
}

async function doInstall(name, game, id, { clean }) {
  const inst = installs.ensure(game);
  setStatus(id, 'installing');
  installs.set(game.id, { status: 'installing', last_error: null });
  try {
    if (clean) await adbShell(name, `cmd package uninstall -k ${game.package_name}`, { timeout: 60000 }).catch(() => {});
    const r = await adb(name, ['install', '-r', '-d', '-g', '/apk/game.apk'], { timeout: 300000 })
      .catch((e) => { throw new Error('APK install failed: ' + e.message + (e.stdout ? ' ' + e.stdout.trim() : '')); });
    if (!/Success/i.test(r.stdout)) throw new Error('APK install failed: ' + r.stdout.trim());
    const st = await installs.deviceState(name, game.package_name);
    if (!st.installed) throw new Error('Install reported success but the package is not present on the device.');
    db.prepare('UPDATE installations SET install_count=install_count+1 WHERE game_id=?').run(game.id);
    installs.set(game.id, {
      status: 'installed', package_name: game.package_name, version_name: st.versionName || game.version_name || '',
      apk_sha256: game.sha256, installed_at: Date.now(), last_verified_at: Date.now(), force_reinstall: 0, last_error: null,
    });
    log(game.id, id, 'info', `APK installed (v${st.versionName || game.version_name || '?'}; install #${inst.install_count + 1})`);
  } catch (e) {
    installs.set(game.id, { status: 'failed', last_error: e.message.slice(0, 500) });
    throw e;
  }
}

async function runOp(name, game, id, op) {
  const pkg = game.package_name;
  const inst = installs.ensure(game);
  if (op === 'reinstall') await doInstall(name, game, id, { clean: true });
  else if (op === 'update') await doInstall(name, game, id, { clean: false });
  else if (op === 'uninstall') {
    const st = await installs.deviceState(name, pkg);
    if (st.installed) {
      const r = await adb(name, ['uninstall', pkg], { timeout: 120000 }).catch((e) => { throw new Error('Uninstall failed: ' + e.message); });
      if (!/Success/i.test(r.stdout)) throw new Error('Uninstall failed: ' + r.stdout.trim());
    }
    installs.set(game.id, { status: 'uninstalled', version_name: null, apk_sha256: null, installed_at: null, force_reinstall: 0, last_error: null });
    log(game.id, id, 'info', 'Game uninstalled from its persistent instance');
  } else if (op === 'clear-data') {
    const st = await installs.deviceState(name, pkg);
    if (!st.installed) throw new Error('The game is not installed, so there is no data to clear.');
    const r = await adbShell(name, `pm clear ${pkg}`, { timeout: 60000 });
    if (!/Success/i.test(r.stdout)) throw new Error('Clear data failed: ' + r.stdout.trim());
    installs.set(game.id, { last_error: null });
    log(game.id, id, 'info', 'Game data cleared');
  } else if (op === 'verify') {
    const st = await installs.deviceState(name, pkg);
    if (st.installed) installs.set(game.id, { status: inst.status === 'installed' ? 'installed' : inst.status, version_name: st.versionName || inst.version_name, last_verified_at: Date.now() });
    else if (inst.status === 'installed') installs.set(game.id, { status: 'failed', last_error: 'Verification: package is missing from the device (registry said installed). It will be reinstalled on next launch.', last_verified_at: Date.now() });
    log(game.id, id, st.installed ? 'info' : 'warn', st.installed ? `Verified: installed (v${st.versionName || '?'})` : 'Verified: NOT installed on the device');
  }
}

async function boot(id) {
  if (booting.has(id)) return;
  booting.add(id);
  try {
    const s = getSession(id); if (!s) return;
    const game = db.prepare('SELECT * FROM games WHERE id=?').get(s.game_id);
    if (!game) throw new Error('Game was deleted.');
    const name = s.container;
    const apkPath = path.join(cfg.apkDir, game.id + '.apk');
    if (!fs.existsSync(apkPath)) throw new Error('APK file is missing from storage.');
    const inst = installs.ensure(game);

    const net = await ensureNetwork();
    await docker(['rm', '-f', name], { timeout: 20000 }).catch(() => {});
    setStatus(id, 'booting');
    log(game.id, id, 'info', `Starting emulator container ${name} on persistent instance ${inst.volume} (${game.min_ram_mb} MB, ${game.cpu_cores} CPU)`);
    const args = ['run', '-d', '--name', name, '--label', 'cloudplay=1',
      '--memory', `${game.min_ram_mb}m`, '--memory-swap', `${game.min_ram_mb}m`, '--cpus', String(game.cpu_cores),
      '--pids-limit', '4096', '--security-opt', 'no-new-privileges', '--network', net,
      '-v', `${apkPath}:/apk/game.apk:ro`,
      '-v', `${inst.volume}:/opt/avd`, // persistent Android data; created on first use from the image's AVD
      '-e', `EMU_RAM_MB=${game.min_ram_mb}`, '-e', `EMU_CORES=${game.cpu_cores}`];
    if (cfg.emulator.useKvm) args.push('--device', '/dev/kvm');
    args.push(cfg.emulator.image);
    await docker(args, { timeout: 120000 });

    await waitForBoot(name, id, game.id);
    const cur = getSession(id);
    if (!cur || !ACTIVE.includes(cur.status)) return;

    const landscape = game.orientation !== 'portrait';
    const [w, h] = landscape ? [1280, 720] : [720, 1280];
    await adbShell(name, `wm size ${w}x${h}; wm density 240; settings put system accelerometer_rotation 0; settings put system user_rotation ${landscape ? 1 : 0}`, { timeout: 20000 });

    // ---- admin maintenance run: perform the operation, then close; no game launch, no streaming ----
    if (s.op) {
      setStatus(id, 'installing');
      await runOp(name, game, id, s.op);
      installs.set(game.id, { busy_op: null });
      log(game.id, id, 'info', `Maintenance "${s.op}" finished`);
      await stopSession(id, `Maintenance "${s.op}" complete`);
      return;
    }

    // ---- normal play: install ONLY when the registry says it is needed ----
    let why = installs.reason(game, inst);
    let clean = false;
    if (!why) {
      const st = await installs.deviceState(name, game.package_name);
      if (!st.installed) { why = 'package missing on the device (corrupted or removed)'; clean = true; }
      else if (game.version_name && st.versionName && st.versionName !== game.version_name) { why = `installed version ${st.versionName} does not match ${game.version_name}`; }
      else {
        installs.set(game.id, { last_verified_at: Date.now() });
        log(game.id, id, 'info', `Already installed (v${st.versionName || inst.version_name || '?'}); skipping install`);
      }
    } else if (inst.force_reinstall) clean = true;
    if (why) {
      log(game.id, id, 'info', `Installing APK: ${why}`);
      await doInstall(name, game, id, { clean });
    }

    setStatus(id, 'launching', { width: w, height: h });
    await launchApp(name, game, id);
    installs.set(game.id, { last_launched_at: Date.now() });

    setStatus(id, 'running');
    log(game.id, id, 'info', 'Game is running');
    events.emit('running', id);
  } finally { booting.delete(id); }
}

async function waitForBoot(name, id, gameId) {
  const deadline = Date.now() + cfg.emulator.bootTimeoutSec * 1000;
  while (Date.now() < deadline) {
    const s = getSession(id);
    if (!s || !ACTIVE.includes(s.status)) return;
    try {
      const r = await adbShell(name, 'getprop sys.boot_completed', { timeout: 8000 });
      if (r.stdout.trim() === '1') { log(gameId, id, 'info', 'Android booted'); return; }
    } catch { /* adb not up yet */ }
    const st = await docker(['inspect', '-f', '{{.State.Running}}', name], { timeout: 8000 }).catch(() => ({ stdout: 'false' }));
    if (st.stdout.trim() !== 'true') {
      const logs = await docker(['logs', '--tail', '15', name], { timeout: 8000 }).then((r) => r.stdout + r.stderr).catch(() => '');
      throw new Error('Emulator container exited during boot. ' + logs.trim().slice(-400));
    }
    await sleep(3000);
  }
  throw new Error(`Emulator did not finish booting within ${cfg.emulator.bootTimeoutSec}s.`);
}

async function launchApp(name, game, playId) {
  if (game.main_activity && !/^[A-Za-z0-9_.$]+$/.test(game.main_activity)) throw new Error('Invalid main activity name.');
  if (!apk.PKG_RE.test(game.package_name)) throw new Error('Invalid package name.');
  const cmd = game.main_activity
    ? `am start -W -n ${game.package_name}/${game.main_activity}`
    : `monkey -p ${game.package_name} -c android.intent.category.LAUNCHER 1`;
  const r = await adbShell(name, cmd, { timeout: 60000 });
  if (/Error|Exception|does not exist/i.test(r.stdout)) throw new Error('Launch failed: ' + r.stdout.trim().slice(0, 300));
  for (let i = 0; i < 20; i++) {
    await sleep(1000);
    const p = await adbShell(name, `pidof ${game.package_name}`, { timeout: 8000 }).catch(() => ({ stdout: '' }));
    if (p.stdout.trim()) { log(game.id, playId, 'info', 'App process verified (pid ' + p.stdout.trim().split(/\s+/)[0] + ')'); return; }
  }
  const lc = await adbShell(name, 'logcat -d -t 40 AndroidRuntime:E *:S', { timeout: 10000 }).then((r2) => r2.stdout.trim().slice(-500)).catch(() => '');
  throw new Error('The app did not start (process not found after 20s). It may be incompatible with this emulator. ' + lc);
}

async function failSession(id, err) {
  const s = getSession(id); if (!s) return;
  if (!ACTIVE.includes(s.status)) return;
  const msg = (err && err.message) || String(err);
  log(s.game_id, id, 'error', msg);
  setStatus(id, 'failed', { error: msg.slice(0, 600), ended_at: Date.now() });
  if (s.op) installs.set(s.game_id, { busy_op: null, last_error: msg.slice(0, 500) });
  events.emit('stopped', id);
  await shutdownContainer(s.container);
}

async function stopSession(id, reason = 'Stopped') {
  const s = getSession(id); if (!s) return false;
  if (ACTIVE.includes(s.status)) {
    setStatus(id, 'stopped', { ended_at: Date.now() });
    log(s.game_id, id, 'info', reason);
    if (s.op) installs.set(s.game_id, { busy_op: null });
  }
  events.emit('stopped', id); // ends streaming immediately; installed games stay on the volume
  await shutdownContainer(s.container);
  return true;
}

async function stopGame(gameId, reason) {
  const rows = db.prepare(`SELECT id FROM play_sessions WHERE game_id=? AND status IN ${ACTIVE_SQL}`).all(gameId);
  await Promise.all(rows.map((r) => stopSession(r.id, reason)));
  return rows.length;
}

authSessions.destroy.hooks.push((authId) => {
  db.prepare(`SELECT id FROM play_sessions WHERE auth_session_id=? AND status IN ${ACTIVE_SQL} AND op IS NULL`).all(authId).forEach((r) => stopSession(r.id, 'Login session ended'));
});

// ---- health monitor ---------------------------------------------------------------------------
async function healthTick() {
  authSessions.purgeExpired();
  const rows = db.prepare(`SELECT * FROM play_sessions WHERE status IN ${ACTIVE_SQL}`).all();
  for (const s of rows) {
    try {
      if (s.expires_at < Date.now()) { await stopSession(s.id, 'Session duration limit reached'); continue; }
      if (s.status !== 'running') continue;
      const game = db.prepare('SELECT * FROM games WHERE id=?').get(s.game_id);
      const st = await docker(['inspect', '-f', '{{.State.Running}}', s.container], { timeout: 8000 }).catch(() => ({ stdout: 'false' }));
      if (st.stdout.trim() !== 'true') { await recover(s, 'Emulator container crashed'); continue; }
      if (game) {
        const p = await adbShell(s.container, `pidof ${game.package_name}`, { timeout: 8000 }).catch(() => null);
        if (p && !p.stdout.trim()) {
          log(s.game_id, s.id, 'warn', 'Game process exited; relaunching');
          await launchApp(s.container, game, s.id).catch((e) => recover(s, 'Game crashed and could not be relaunched: ' + e.message));
        }
      }
    } catch (e) { console.error('health tick', e.message); }
  }
}

async function recover(s, why) {
  log(s.game_id, s.id, 'error', why);
  if (s.restarts >= MAX_AUTO_RESTARTS) { await failSession(s.id, new Error(why + ' (automatic restart limit reached)')); return; }
  setStatus(s.id, 'starting', { restarts: s.restarts + 1, error: null });
  events.emit('stopped', s.id);
  boot(s.id).catch((e) => failSession(s.id, e)); // same persistent volume: nothing is reinstalled
}

// On startup: close sessions left over from the previous process and stop their containers cleanly.
// Volumes and the installation registry are NOT touched, so installed games survive restarts.
async function cleanupOrphans() {
  db.prepare(`UPDATE play_sessions SET status='stopped', ended_at=?, error='Server restarted' WHERE status IN ${ACTIVE_SQL}`).run(Date.now());
  db.prepare('UPDATE installations SET busy_op=NULL').run();
  db.prepare("UPDATE installations SET status='failed', last_error='Interrupted by a server restart; will retry on next launch.' WHERE status='installing'").run();
  try {
    const { stdout } = await docker(['ps', '-a', '--filter', 'label=cloudplay=1', '--format', '{{.Names}}'], { timeout: 10000 });
    const names = stdout.split('\n').map((x) => x.trim()).filter(Boolean);
    await Promise.all(names.map(shutdownContainer));
  } catch { /* docker not installed yet */ }
}

function startMonitor() { setInterval(() => healthTick().catch(() => {}), 15000).unref(); }

module.exports = { events, OPS, startSession, stopSession, stopGame, getSession, runtimeStatus, cleanupOrphans, startMonitor, healthTick, containerName, HttpError };
