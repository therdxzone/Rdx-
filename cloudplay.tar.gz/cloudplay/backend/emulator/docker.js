'use strict';
const { execFile, spawn } = require('child_process');

function docker(args, { timeout = 60000, input } = {}) {
  return new Promise((resolve, reject) => {
    const p = execFile('docker', args, { timeout, maxBuffer: 8 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) { const e = new Error((stderr || err.message || '').trim().split('\n').slice(-3).join(' ')); e.code = err.code; e.stdout = stdout; return reject(e); }
      resolve({ stdout: stdout.toString(), stderr: stderr.toString() });
    });
    if (input) { p.stdin.end(input); }
  });
}

// Run `adb <args>` inside the session's container. The adb server/emulator ports are never published to the host.
const adb = (container, args, opts) => docker(['exec', container, 'adb', ...args], opts);
const adbShell = (container, cmd, opts) => adb(container, ['shell', cmd], opts);

// Long-running spawn variants for streaming and input.
const spawnAdb = (container, args, stdio) => spawn('docker', ['exec', '-i', container, 'adb', ...args], { stdio: stdio || ['pipe', 'pipe', 'pipe'] });

module.exports = { docker, adb, adbShell, spawnAdb };
