'use strict';
const { db } = require('../database/db');
const ins = db.prepare('INSERT INTO audit_logs(ts,role,action,detail,ip) VALUES(?,?,?,?,?)');

function audit(req, action, detail) {
  try {
    ins.run(Date.now(), req && req.auth ? req.auth.role : null, action, detail ? String(detail).slice(0, 500) : null, req ? clientIp(req) : null);
  } catch (e) { console.error('audit failed', e.message); }
}
function clientIp(req) {
  return req.ip || (req.socket && req.socket.remoteAddress) || '';
}
module.exports = { audit, clientIp };
