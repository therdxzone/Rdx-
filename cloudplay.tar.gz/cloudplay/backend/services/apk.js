'use strict';
const fs = require('fs');
const crypto = require('crypto');
const yauzl = require('yauzl');

// Read zip central directory only (never extracts to disk). Returns entry names.
function listEntries(file) {
  return new Promise((resolve, reject) => {
    yauzl.open(file, { lazyEntries: true, autoClose: true }, (err, zip) => {
      if (err) return reject(new Error('Not a valid ZIP/APK archive.'));
      const names = [];
      zip.on('entry', (e) => { names.push(e.fileName); if (names.length > 200000) { zip.close(); return reject(new Error('Archive has too many entries.')); } zip.readEntry(); });
      zip.on('end', () => resolve(names));
      zip.on('error', reject);
      zip.readEntry();
    });
  });
}

function sha256File(file) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash('sha256');
    fs.createReadStream(file).on('data', (d) => h.update(d)).on('end', () => resolve(h.digest('hex'))).on('error', reject);
  });
}

function magicIs(file, bytes) {
  const fd = fs.openSync(file, 'r');
  try { const b = Buffer.alloc(bytes.length); fs.readSync(fd, b, 0, bytes.length, 0); return b.equals(Buffer.from(bytes)); } finally { fs.closeSync(fd); }
}

const PKG_RE = /^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$/;

// Validates the file really is an APK and extracts metadata. Throws Error with a user-facing message.
async function inspect(file) {
  if (!magicIs(file, [0x50, 0x4b, 0x03, 0x04])) throw new Error('File is not an APK (missing ZIP signature).');
  const names = await listEntries(file);
  if (!names.includes('AndroidManifest.xml')) throw new Error('APK is missing AndroidManifest.xml.');
  if (!names.some((n) => /^classes\d*\.dex$/.test(n))) throw new Error('APK contains no classes.dex (not a runnable Android app).');
  if (names.some((n) => n.includes('..') || n.startsWith('/'))) throw new Error('APK contains unsafe paths.');

  const abis = [...new Set(names.map((n) => /^lib\/([^/]+)\//.exec(n)).filter(Boolean).map((m) => m[1]))];

  const meta = { packageName: '', versionName: '', mainActivity: '', label: '', abis };
  try {
    const ApkReader = require('adbkit-apkreader');
    const reader = await ApkReader.open(file);
    const m = await reader.readManifest();
    meta.packageName = m.package || '';
    meta.versionName = m.versionName ? String(m.versionName) : '';
    const acts = (m.application && m.application.activities) || [];
    for (const a of acts) {
      const filters = a.intentFilters || [];
      const isLauncher = filters.some((f) => (f.categories || []).some((c) => c.name === 'android.intent.category.LAUNCHER'));
      if (isLauncher) { meta.mainActivity = a.name || ''; break; }
    }
    if (m.application && typeof m.application.label === 'string') meta.label = m.application.label;
  } catch (e) {
    meta.warning = 'Could not parse manifest automatically (' + e.message + '). Enter the package name manually.';
  }
  if (meta.mainActivity && meta.packageName && meta.mainActivity.startsWith('.')) meta.mainActivity = meta.packageName + meta.mainActivity;
  if (meta.packageName && !PKG_RE.test(meta.packageName)) throw new Error('APK package name is invalid.');
  meta.sha256 = await sha256File(file);
  meta.sizeBytes = fs.statSync(file).size;
  return meta;
}

function isCompatible(abisInApk, allowedAbis, armTranslation) {
  if (!abisInApk.length) return { ok: true }; // pure Java/Kotlin or unity-less: runs anywhere
  const allowed = new Set(allowedAbis);
  if (abisInApk.some((a) => allowed.has(a))) return { ok: true };
  if (armTranslation && abisInApk.some((a) => a.startsWith('arm'))) return { ok: true, note: 'Runs via ARM translation (slower).' };
  return { ok: false, reason: `APK ships native libraries only for [${abisInApk.join(', ')}], but this emulator supports [${allowedAbis.join(', ')}]. Use an x86_64 build of the game or an emulator image with ARM translation.` };
}

const IMG_MAGIC = [
  { ext: '.png', bytes: [0x89, 0x50, 0x4e, 0x47] },
  { ext: '.jpg', bytes: [0xff, 0xd8, 0xff] },
  { ext: '.webp', bytes: null },
];
function detectImageExt(file) {
  for (const m of IMG_MAGIC) if (m.bytes && magicIs(file, m.bytes)) return m.ext;
  const fd = fs.openSync(file, 'r');
  try { const b = Buffer.alloc(12); fs.readSync(fd, b, 0, 12, 0); if (b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP') return '.webp'; } finally { fs.closeSync(fd); }
  return null;
}

module.exports = { inspect, isCompatible, detectImageExt, PKG_RE, sha256File };
