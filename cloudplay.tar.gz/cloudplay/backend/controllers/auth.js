'use strict';
const { db, settings } = require('../database/db');
const pw = require('../security/passwords');
const sessions = require('../services/authSessions');
const { audit } = require('../services/audit');
const cfg = require('../config');

const DUMMY = '$argon2id$v=19$m=19456,t=2,p=1$c29tZXNhbHRzb21lc2FsdA$0000000000000000000000000000000000000000000';

function setCookie(res, token) {
  res.cookie(sessions.COOKIE, token, {
    httpOnly: true,
    secure: cfg.cookieSecure,
    sameSite: 'strict',
    path: '/',
    maxAge: settings.int('session_timeout_min') * 60000,
  });
}

async function login(req, res) {
  const { password, mode } = req.body || {};
  if (typeof password !== 'string' || !password || password.length > 200) return res.status(400).json({ error: 'Password required.' });
  const wantAdmin = mode === 'admin';
  // The role is decided by WHICH stored hash matches, never by the client.
  const hash = settings.get(wantAdmin ? 'admin_hash' : 'user_hash');
  const ok = await pw.verify(hash || DUMMY, password);
  if (!ok || !hash) {
    audit({ ip: req.ip, auth: null }, 'login_failed', wantAdmin ? 'admin mode' : 'user mode');
    return res.status(401).json({ error: 'Incorrect password.' });
  }
  const role = wantAdmin ? 'admin' : 'user';
  if (role === 'user') {
    if (settings.get('user_access_enabled') !== '1') return res.status(403).json({ error: 'User access is currently disabled by the administrator.' });
    sessions.purgeExpired();
    if (sessions.countActive('user') >= settings.int('max_concurrent_sessions')) {
      return res.status(429).json({ error: 'The server is at its maximum number of concurrent sessions. Try again later.' });
    }
  }
  const { token, csrf } = sessions.create(role, req);
  setCookie(res, token);
  req.auth = { role };
  audit(req, 'login', role);
  res.json({ role, csrf, siteName: settings.get('site_name') });
}

function logout(req, res) {
  if (req.auth) { audit(req, 'logout'); sessions.destroy(req.auth.id); }
  res.clearCookie(sessions.COOKIE, { path: '/' });
  res.json({ ok: true });
}

function me(req, res) {
  if (!req.auth) return res.status(401).json({ error: 'Not signed in.', siteName: settings.get('site_name') });
  res.json({ role: req.auth.role, csrf: req.auth.csrf, siteName: settings.get('site_name') });
}

function publicInfo(_req, res) {
  res.json({ siteName: settings.get('site_name'), userAccess: settings.get('user_access_enabled') === '1' });
}

module.exports = { login, logout, me, publicInfo };
