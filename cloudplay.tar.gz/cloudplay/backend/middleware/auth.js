'use strict';
const crypto = require('crypto');
const sessions = require('../services/authSessions');

// Attaches req.auth = {id, role, csrf} when a valid session cookie exists.
function attachAuth(req, _res, next) {
  const s = sessions.lookup(req.cookies && req.cookies[sessions.COOKIE]);
  if (s) req.auth = s;
  next();
}

function requireAuth(req, res, next) {
  if (!req.auth) return res.status(401).json({ error: 'Not signed in.' });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.auth) return res.status(401).json({ error: 'Not signed in.' });
  if (req.auth.role !== 'admin') return res.status(403).json({ error: 'Admin only.' });
  next();
}

function safeEq(a, b) {
  const x = Buffer.from(String(a || '')); const y = Buffer.from(String(b || ''));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

// CSRF: every state-changing request on an authenticated session must carry the session's token
// in X-CSRF-Token. SameSite=Strict cookies + Origin check give defence in depth.
function csrfProtect(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.headers.origin;
  if (origin) {
    let ok = false;
    try { ok = new URL(origin).host === req.headers.host; } catch { /* bad origin */ }
    if (!ok) return res.status(403).json({ error: 'Bad origin.' });
  }
  if (req.path === '/api/auth/login') return next(); // no session yet; protected by SameSite + origin + rate limit
  if (!req.auth) return next(); // handlers reject unauthenticated callers themselves
  if (!safeEq(req.headers['x-csrf-token'], req.auth.csrf)) return res.status(403).json({ error: 'Invalid CSRF token.' });
  next();
}

module.exports = { attachAuth, requireAuth, requireAdmin, csrfProtect };
