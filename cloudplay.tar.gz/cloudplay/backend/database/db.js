'use strict';
const Database = require('better-sqlite3');
const cfg = require('../config');

const db = new Database(cfg.dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS games (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  package_name TEXT NOT NULL,
  main_activity TEXT NOT NULL DEFAULT '',
  version_name TEXT NOT NULL DEFAULT '',
  sha256 TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  abis TEXT NOT NULL DEFAULT '',
  orientation TEXT NOT NULL DEFAULT 'landscape',
  min_ram_mb INTEGER NOT NULL DEFAULT 2048,
  cpu_cores INTEGER NOT NULL DEFAULT 2,
  enabled INTEGER NOT NULL DEFAULT 1,
  icon_file TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS auth_sessions (
  id TEXT PRIMARY KEY,            -- sha256 of the cookie token
  role TEXT NOT NULL CHECK (role IN ('admin','user')),
  csrf TEXT NOT NULL,
  ip TEXT, user_agent TEXT,
  created_at INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS play_sessions (
  id TEXT PRIMARY KEY,
  auth_session_id TEXT,
  role TEXT NOT NULL,
  game_id TEXT NOT NULL,
  container TEXT,
  status TEXT NOT NULL,           -- starting|booting|installing|launching|running|stopped|failed|crashed
  error TEXT,
  restarts INTEGER NOT NULL DEFAULT 0,
  width INTEGER, height INTEGER,
  started_at INTEGER NOT NULL,
  ended_at INTEGER,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_play_status ON play_sessions(status);

-- Installation registry: survives restarts, logouts and session cleanup. One persistent emulator
-- instance (a Docker volume holding the Android data) exists per game.
CREATE TABLE IF NOT EXISTS installations (
  game_id TEXT PRIMARY KEY,
  package_name TEXT NOT NULL,
  version_name TEXT,
  apk_sha256 TEXT,
  volume TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'not_installed',  -- not_installed|installing|installed|failed|uninstalled
  force_reinstall INTEGER NOT NULL DEFAULT 0,
  busy_op TEXT,
  install_count INTEGER NOT NULL DEFAULT 0,
  installed_at INTEGER, last_launched_at INTEGER, last_verified_at INTEGER,
  last_error TEXT,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS game_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  game_id TEXT, play_id TEXT, level TEXT NOT NULL, message TEXT NOT NULL, ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_game_logs_game ON game_logs(game_id, id);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL, role TEXT, action TEXT NOT NULL, detail TEXT, ip TEXT
);
`);

{ // migration: maintenance operations run as a special kind of emulator session
  const cols = db.prepare('PRAGMA table_info(play_sessions)').all().map((c) => c.name);
  if (!cols.includes('op')) db.exec('ALTER TABLE play_sessions ADD COLUMN op TEXT');
}

const DEFAULTS = {
  site_name: 'CloudPlay',
  user_access_enabled: '1',
  max_concurrent_sessions: '5',      // concurrent logged-in sessions
  session_timeout_min: '120',        // login session lifetime (idle sliding)
  max_upload_mb: '500',
  max_emulators: '2',
  ram_per_emulator_mb: '2048',
  cpu_per_emulator: '2',
  play_duration_min: '60',
  android_label: 'Android 13 (API 33)',
};

const getStmt = db.prepare('SELECT value FROM settings WHERE key = ?');
const setStmt = db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');

const settings = {
  get(key) {
    const row = getStmt.get(key);
    return row ? row.value : DEFAULTS[key];
  },
  int(key) { return parseInt(this.get(key), 10); },
  set(key, value) { setStmt.run(key, String(value)); },
  all() {
    const out = { ...DEFAULTS };
    for (const r of db.prepare("SELECT key,value FROM settings WHERE key NOT IN ('admin_hash','user_hash')").all()) out[r.key] = r.value;
    return out;
  },
  DEFAULTS,
};

module.exports = { db, settings };
