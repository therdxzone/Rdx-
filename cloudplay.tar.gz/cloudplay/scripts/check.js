'use strict';
// Quick self-check of the runtime environment: node scripts/check.js
const fs = require('fs');
const { execFileSync } = require('child_process');
const ok = (c, m) => console.log((c ? '[ok]   ' : '[FAIL] ') + m);
const has = (cmd, args = ['--version']) => { try { execFileSync(cmd, args, { stdio: 'ignore' }); return true; } catch { return false; } };
ok(fs.existsSync('/dev/kvm'), '/dev/kvm present (hardware acceleration)');
ok(has('docker'), 'docker installed');
ok(has('ffmpeg', ['-version']), 'ffmpeg installed (used to decode the live screen capture)');
try { execFileSync('docker', ['image', 'inspect', process.env.EMULATOR_IMAGE || 'cloudplay/android-emulator:latest'], { stdio: 'ignore' }); ok(true, 'emulator image built'); } catch { ok(false, 'emulator image built (docker build -t cloudplay/android-emulator:latest emulator/image)'); }
try { require('@roamhq/wrtc'); ok(true, 'wrtc native module loads'); } catch (e) { ok(false, 'wrtc native module: ' + e.message); }
try { require('better-sqlite3'); ok(true, 'better-sqlite3 loads'); } catch (e) { ok(false, 'better-sqlite3: ' + e.message); }
try { require('argon2'); ok(true, 'argon2 loads'); } catch (e) { ok(false, 'argon2: ' + e.message); }
