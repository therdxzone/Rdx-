module.exports={apps:[{name:'wt-api',script:'server.js',env:{SECURE:'1',PORT:3000}},{name:'wt-worker',script:'worker.js',max_memory_restart:'1500M'}]};
