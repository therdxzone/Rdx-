const dns=require('dns').promises,net=require('net');
const BAD=/^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.|::1$|::$|f[cd]|fe[89ab]|::ffff:)/i;
module.exports=async u=>{try{const x=new URL(u);if(!/^https?:$/.test(x.protocol))return false;const h=x.hostname.replace(/^\[|\]$/g,'');
const ips=net.isIP(h)?[h]:(await dns.lookup(h,{all:true})).map(a=>a.address);return ips.length>0&&ips.every(ip=>!BAD.test(ip))}catch{return false}};
