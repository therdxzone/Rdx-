#!/usr/bin/env bash
# Usage: sudo bash install.sh your-domain.com you@email.com   (run from the project folder)
set -e; D=${1:?domain}; E=${2:?email}; DIR=$(pwd)
apt-get update && apt-get install -y curl nginx certbot python3-certbot-nginx build-essential
curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs
npm i -g pm2 && npm install --omit=dev && npx playwright install --with-deps chromium
pm2 start ecosystem.config.js && pm2 save && pm2 startup systemd -u $USER --hp $HOME | tail -1 | bash
cat >/etc/nginx/sites-available/webtrigger <<N
server{listen 80;server_name $D;client_max_body_size 1m;location /{proxy_pass http://127.0.0.1:3000;proxy_set_header Host \$host;proxy_set_header X-Real-IP \$remote_addr;proxy_set_header X-Forwarded-Proto \$scheme;}}
N
ln -sf /etc/nginx/sites-available/webtrigger /etc/nginx/sites-enabled/ && nginx -t && systemctl reload nginx
certbot --nginx -d $D -m $E --agree-tos -n --redirect
echo "Done: https://$D  (first registered user becomes admin)"
