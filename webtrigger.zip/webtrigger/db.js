const D=require('better-sqlite3')(process.env.DB||'webtrigger.db');D.pragma('journal_mode=WAL');D.pragma('busy_timeout=5000');
D.exec(`create table if not exists users(id integer primary key,username text unique,hash text,role text default 'user',suspended int default 0);
create table if not exists sessions(token text primary key,uid int);
create table if not exists triggers(id integer primary key,uid int,name text,selector text,delay int default 2,pos int,enabled int default 1);
create table if not exists auto(uid int primary key,url text,status text default 'stopped',every int default 600,cycles int default 0,ok int default 0,fail int default 0,streak int default 0,started int,last int,next int,cur text);
create table if not exists history(id integer primary key,uid int,ts int,trig text,status text,dur int,err text,cycle int);
create table if not exists perf(id integer primary key,uid int,ts int,load int,httperr int,jserr int,reqfail int,rss int,cpu int);
create table if not exists meta(k text primary key,v text);`);
module.exports=D;
