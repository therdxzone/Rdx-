# WebTrigger
Local: npm install && npx playwright install chromium && (node server.js & node worker.js)  -> http://127.0.0.1:3000
VPS:   sudo bash install.sh your-domain.com you@email.com
First registered user = admin. Data: webtrigger.db (SQLite, WAL). API and worker are separate PM2 processes; the worker keeps running automations when users log out or close the site and resumes 'running' automations after a restart.
