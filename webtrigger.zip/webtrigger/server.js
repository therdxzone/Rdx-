const express=require('express'),bcrypt=require('bcryptjs'),crypto=require('crypto'),{chromium}=require('playwright'),db=require('./db'),safe=require('./safe');
const app=express();app.set('trust proxy',1),now=()=>Math.floor(Date.now()/1000),W=1000,H=700;app.use(express.json({limit:'50kb'}));app.use(express.static('public'));
const ck=r=>(r.headers.cookie||'').split(';').map(s=>s.trim().split('=')).find(a=>a[0]=='t')?.[1];
const err=(s,m,c=400)=>s.status(c).json({error:m});
const give=(s,id)=>{const t=crypto.randomBytes(32).toString('hex');db.prepare('insert into sessions values(?,?)').run(t,id);s.cookie('t',t,{httpOnly:true,sameSite:'lax',secure:!!process.env.SECURE,maxAge:30*864e5})};
const tries=new Map();const limited=ip=>{const a=(tries.get(ip)||[]).filter(t=>Date.now()-t<6e4);a.push(Date.now());tries.set(ip,a);return a.length>10};
app.post('/api/register',(q,s)=>{if(limited(q.ip))return err(s,'Too many attempts');const{username:u,password:p,confirm:c}=q.body;
if(!/^[a-zA-Z0-9_]{3,24}$/.test(u||''))return err(s,'Username: 3-24 letters, numbers, _');if(!p||p.length<8)return err(s,'Password min 8 chars');if(p!==c)return err(s,'Passwords do not match');
if(db.prepare('select 1 from users where username=? collate nocase').get(u))return err(s,'Username taken');
const first=!db.prepare('select 1 from users').get();const r=db.prepare('insert into users(username,hash,role) values(?,?,?)').run(u,bcrypt.hashSync(p,12),first?'admin':'user');give(s,r.lastInsertRowid);s.json({ok:1})});
app.post('/api/login',(q,s)=>{if(limited(q.ip))return err(s,'Too many attempts');const{username:u,password:p}=q.body;const r=db.prepare('select * from users where username=? collate nocase').get(u||'');
if(!r||!bcrypt.compareSync(p||'',r.hash))return err(s,'Invalid username or password');if(r.suspended)return err(s,'Account suspended',403);give(s,r.id);s.json({ok:1})});
app.use('/api',(q,s,n)=>{const r=db.prepare('select u.* from sessions x join users u on u.id=x.uid where token=?').get(ck(q)||'');if(!r||r.suspended)return err(s,'auth',401);q.u=r;n()});
app.get('/api/me',(q,s)=>s.json({id:q.u.id,username:q.u.username,role:q.u.role}));
app.post('/api/logout',(q,s)=>{db.prepare('delete from sessions where token=?').run(ck(q));s.clearCookie('t');s.json({ok:1})});
app.post('/api/password',(q,s)=>{const{old,nw}=q.body;if(!bcrypt.compareSync(old||'',q.u.hash))return err(s,'Wrong current password');if(!nw||nw.length<8)return err(s,'Password min 8 chars');
db.prepare('update users set hash=? where id=?').run(bcrypt.hashSync(nw,12),q.u.id);s.json({ok:1})});
// triggers
const T=uid=>db.prepare('select * from triggers where uid=? order by pos').all(uid);
app.get('/api/triggers',(q,s)=>s.json(T(q.u.id)));
app.post('/api/triggers',(q,s)=>{const{name,selector,delay}=q.body;if(!name||!selector)return err(s,'name and selector required');if(T(q.u.id).length>=30)return err(s,'Trigger quota reached (30)');
const p=(db.prepare('select max(pos) m from triggers where uid=?').get(q.u.id).m??0)+1;db.prepare('insert into triggers(uid,name,selector,delay,pos) values(?,?,?,?,?)').run(q.u.id,String(name).slice(0,60),String(selector).slice(0,500),Math.min(Math.max(+delay||0,0),3600),p);s.json({ok:1})});
app.put('/api/triggers/:id',(q,s)=>{const o=db.prepare('select * from triggers where id=? and uid=?').get(q.params.id,q.u.id);if(!o)return err(s,'Not found',404);const b={...o,...q.body};
db.prepare('update triggers set name=?,selector=?,delay=?,enabled=? where id=?').run(String(b.name).slice(0,60),String(b.selector).slice(0,500),Math.min(Math.max(+b.delay||0,0),3600),b.enabled?1:0,o.id);s.json({ok:1})});
app.delete('/api/triggers/:id',(q,s)=>{db.prepare('delete from triggers where id=? and uid=?').run(q.params.id,q.u.id);s.json({ok:1})});
app.post('/api/triggers/:id/dup',(q,s)=>{const o=db.prepare('select * from triggers where id=? and uid=?').get(q.params.id,q.u.id);if(!o)return err(s,'Not found',404);if(T(q.u.id).length>=30)return err(s,'Quota reached');
db.prepare('update triggers set pos=pos+1 where uid=? and pos>?').run(q.u.id,o.pos);db.prepare('insert into triggers(uid,name,selector,delay,pos,enabled) values(?,?,?,?,?,?)').run(q.u.id,o.name+' copy',o.selector,o.delay,o.pos+1,o.enabled);s.json({ok:1})});
app.post('/api/triggers/:id/move',(q,s)=>{const l=T(q.u.id),i=l.findIndex(x=>x.id==q.params.id),j=i+(q.body.dir=='up'?-1:1);if(i<0||j<0||j>=l.length)return s.json({ok:1});
db.prepare('update triggers set pos=? where id=?').run(l[j].pos,l[i].id);db.prepare('update triggers set pos=? where id=?').run(l[i].pos,l[j].id);s.json({ok:1})});
// automation
app.get('/api/auto',(q,s)=>s.json({a:db.prepare('select * from auto where uid=?').get(q.u.id)||null,triggers:T(q.u.id).length,now:now()}));
app.post('/api/auto/:act',async(q,s)=>{const u=q.u.id,a=db.prepare('select * from auto where uid=?').get(u),act=q.params.act,set=(st,x='')=>db.prepare(`update auto set status=?${x} where uid=?`).run(st,u);
if(act=='delete'){db.prepare('delete from auto where uid=?').run(u);return s.json({ok:1})}
if(act=='start'||act=='restart'){const{url,every,authorized}=q.body;if(!authorized)return err(s,'Confirm you own or are authorized to automate this site');if(!await safe(url))return err(s,'URL not allowed (invalid or private address)');
if(!T(u).some(t=>t.enabled))return err(s,'Add at least one enabled trigger');const e=Math.max(60,Math.min(+every||600,86400*7));
db.prepare(`insert into auto(uid,url,status,every,started,next) values(?,?, 'running',?,?,?) on conflict(uid) do update set url=?,status='running',every=?,cycles=0,ok=0,fail=0,streak=0,started=?,next=?,cur=null`).run(u,url,e,now(),now(),url,e,now(),now());return s.json({ok:1})}
if(!a)return err(s,'No automation');if(act=='pause')set('paused');else if(act=='resume')set('running',',next='+now());else if(act=='stop')set('stopped',',cur=null');else return err(s,'bad action');s.json({ok:1})});
app.get('/api/history',(q,s)=>s.json(db.prepare('select * from history where uid=? order by id desc limit 200').all(q.u.id)));
app.get('/api/perf',(q,s)=>s.json(db.prepare('select * from (select * from perf where uid=? order by id desc limit 100) order by id').all(q.u.id)));
// remote browser
const B=new Map();let br;
async function pg(uid){let b=B.get(uid);if(b){b.t=Date.now();return b.p}if(B.size>=10)throw new Error('Too many browser sessions');
if(!br||!br.isConnected())br=await chromium.launch({args:['--no-sandbox']});const c=await br.newContext({viewport:{width:W,height:H}});
await c.route('**/*',async r=>{const u=r.request().url();(/^(data|blob):/.test(u)||await safe(u))?r.continue().catch(()=>{}):r.abort().catch(()=>{})});
const p=await c.newPage();p.on('popup',x=>x.close().catch(()=>{}));B.set(uid,{c,p,t:Date.now()});return p}
setInterval(()=>{for(const[k,v]of B)if(Date.now()-v.t>6e5){v.c.close().catch(()=>{});B.delete(k)}},6e4);
const wrap=f=>async(q,s)=>{try{await f(q,s)}catch(e){err(s,String(e.message).split('\n')[0])}};
app.post('/api/br/open',wrap(async(q,s)=>{if(!await safe(q.body.url))return err(s,'URL not allowed (invalid or private address)');const p=await pg(q.u.id);await p.goto(q.body.url,{timeout:30000}).catch(e=>{if(!/ERR_ABORTED/.test(e.message))throw e});s.json({url:p.url()})}));
app.get('/api/br/shot',wrap(async(q,s)=>{const b=B.get(q.u.id);if(!b)return err(s,'No open page',404);s.set('X-Url',encodeURIComponent(b.p.url())).type('jpeg').send(await b.p.screenshot({type:'jpeg',quality:60}))}));
app.post('/api/br/nav',wrap(async(q,s)=>{const p=await pg(q.u.id),a=q.body.a;if(a=='back')await p.goBack();else if(a=='forward')await p.goForward();else await p.reload();s.json({ok:1})}));
app.post('/api/br/click',wrap(async(q,s)=>{const p=await pg(q.u.id);await p.mouse.click(+q.body.x,+q.body.y);s.json({ok:1})}));
app.post('/api/br/scroll',wrap(async(q,s)=>{const p=await pg(q.u.id);await p.mouse.wheel(0,+q.body.dy||0);s.json({ok:1})}));
app.post('/api/br/type',wrap(async(q,s)=>{const p=await pg(q.u.id);await p.keyboard.type(String(q.body.text||'').slice(0,200));s.json({ok:1})}));
app.post('/api/br/pick',wrap(async(q,s)=>{const p=await pg(q.u.id);const r=await p.evaluate(([x,y])=>{const e=document.elementFromPoint(x,y);if(!e)return null;const path=[];let n=e;
while(n&&n.nodeType==1&&n!==document.body){if(n.id){path.unshift('#'+CSS.escape(n.id));break}let t=n.tagName.toLowerCase();const par=n.parentElement;if(par){const sib=[...par.children].filter(c=>c.tagName==n.tagName);if(sib.length>1)t+=':nth-of-type('+(sib.indexOf(n)+1)+')'}path.unshift(t);n=par}
return{selector:path.join(' > '),text:(e.innerText||e.value||'').trim().slice(0,40),tag:e.tagName.toLowerCase()}},[+q.body.x,+q.body.y]);s.json(r||{})}));
// admin
const adm=(q,s,n)=>q.u.role=='admin'?n():err(s,'Forbidden',403);
app.get('/api/admin',adm,(q,s)=>{let hb={};try{hb=JSON.parse(db.prepare("select v from meta where k='hb'").get()?.v||'{}')}catch{}
s.json({now:now(),hb,sessions:B.size,users:db.prepare('select u.id,username,role,suspended,(select count(*) from triggers where uid=u.id) triggers,a.status,a.fail,a.cycles from users u left join auto a on a.uid=u.id').all(),
active:db.prepare("select count(*) n from auto where status='running'").get().n,logs:db.prepare("select h.*,username from history h join users u on u.id=h.uid where status='failed' order by h.id desc limit 100").all()})});
app.post('/api/admin/suspend/:id',adm,(q,s)=>{const id=+q.params.id;if(id==q.u.id)return err(s,'Cannot suspend yourself');const u=db.prepare('select suspended from users where id=?').get(id);if(!u)return err(s,'Not found',404);const v=u.suspended?0:1;
db.prepare('update users set suspended=? where id=?').run(v,id);if(v){db.prepare('delete from sessions where uid=?').run(id);db.prepare("update auto set status='stopped' where uid=?").run(id);const b=B.get(id);if(b){b.c.close().catch(()=>{});B.delete(id)}}s.json({ok:1})});
app.listen(process.env.PORT||3000,'127.0.0.1',()=>console.log('WebTrigger API up'));
