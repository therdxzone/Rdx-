const db=require('./db'),{chromium}=require('playwright'),safe=require('./safe'),{execSync}=require('child_process'),os=require('os');
let br;const busy=new Set(),now=()=>Math.floor(Date.now()/1000),sleep=ms=>new Promise(r=>setTimeout(r,ms)),MAX=+process.env.MAX_CONCURRENT||5;
const ram=()=>{try{return +execSync("ps -eo rss,comm | awk '/chrom/{s+=$1}END{print s*1024+0}'").toString()}catch{return 0}};
async function cycle(a){const U=a.uid,cyc=a.cycles+1,m={load:0,http:0,js:0,rf:0},trig=db.prepare('select * from triggers where uid=? and enabled=1 order by pos').all(U);let ok=true,ctx;
const log=(t,s,d,e,at)=>db.prepare('insert into history(uid,ts,trig,status,dur,err,cycle) values(?,?,?,?,?,?,?)').run(U,at||now(),t,s,d,e||null,cyc);
const st=()=>db.prepare('select status from auto where uid=?').get(U)?.status,fail=(t,d,e,at)=>{ok=false;db.prepare('update auto set fail=fail+1 where uid=?').run(U);log(t,'failed',d,String(e.message||e).split('\n')[0].slice(0,300),at)};
try{ctx=await br.newContext({viewport:{width:1000,height:700}});await ctx.route('**/*',async r=>{const u=r.request().url();(/^(data|blob):/.test(u)||await safe(u))?r.continue().catch(()=>{}):r.abort().catch(()=>{})});
const p=await ctx.newPage();p.on('response',r=>{if(r.status()>=400)m.http++});p.on('pageerror',()=>m.js++);p.on('requestfailed',()=>m.rf++);
let t0=Date.now();try{await p.goto(a.url,{timeout:30000});m.load=Date.now()-t0}catch(e){fail('Page load',Date.now()-t0,e)}
if(ok)for(const t of trig){db.prepare('update auto set cur=? where uid=?').run('Waiting '+t.delay+'s: '+t.name,U);
for(let w=t.delay*1000;w>0&&st()=='running';w-=Math.min(w,1000))await sleep(Math.min(w,1000));
if(st()!='running'){ok=null;break}db.prepare('update auto set cur=? where uid=?').run(t.name,U);const at=now();t0=Date.now();
try{await p.click(t.selector,{timeout:10000});db.prepare('update auto set ok=ok+1 where uid=?').run(U);log(t.name,'success',Date.now()-t0,null,at)}catch(e){fail(t.name,Date.now()-t0,e,at);break}}
}catch(e){fail('Worker',0,e)}finally{await ctx?.close().catch(()=>{})}
db.prepare('insert into perf(uid,ts,load,httperr,jserr,reqfail,rss,cpu) values(?,?,?,?,?,?,?,?)').run(U,now(),m.load,m.http,m.js,m.rf,ram(),Math.round(os.loadavg()[0]*100));
if(ok===null){db.prepare('update auto set cur=null where uid=?').run(U);return}
const streak=ok?0:a.streak+1;const stop=streak>=5;if(stop)log('Auto-stop','failed',0,'5 consecutive failed cycles - automation stopped');
db.prepare('update auto set cycles=cycles+1,last=?,cur=null,streak=?,next=?,status=case when ?=1 then \'stopped\' else status end where uid=?').run(now(),streak,now()+a.every,stop?1:0,U)}
(async()=>{br=await chromium.launch({args:['--no-sandbox']});console.log('Worker up');
setInterval(()=>db.prepare("insert or replace into meta values('hb',?)").run(JSON.stringify({t:now(),rss:process.memoryUsage().rss,busy:busy.size,load:os.loadavg()[0],browserRam:ram()})),5000);
for(;;){try{if(!br.isConnected())br=await chromium.launch({args:['--no-sandbox']});
for(const a of db.prepare("select a.* from auto a join users u on u.id=a.uid where a.status='running' and a.next<=? and u.suspended=0").all(now())){if(busy.size>=MAX)break;if(busy.has(a.uid))continue;busy.add(a.uid);cycle(a).catch(console.error).finally(()=>busy.delete(a.uid))}}catch(e){console.error(e)}await sleep(2000)}})();
